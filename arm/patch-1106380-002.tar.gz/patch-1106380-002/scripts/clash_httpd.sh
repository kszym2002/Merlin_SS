#!/bin/sh

eval $(dbus export merlinclash)
source /koolshare/scripts/base.sh
source helper.sh
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'

if [ "$merlinclash_enable" == "1" ]; then
    #echo_date "开始检查进程状态..."
    httpd=$(ps | grep -w httpd | grep -v grep)
    if [ ! -n "$httpd" ]; then
        service restart_httpd
    fi
fi
