#! /bin/sh

# shadowsocks script for HND/AXHND router with kernel 4.1.27/4.1.51 merlin firmware

source /koolshare/scripts/base.sh
eval $(dbus export merlinclash)
alias echo_date='echo 【$(TZ=UTC-8 date -R +%Y年%m月%d日\ %X)】:'
MODEL=$(nvram get productid)
LOG_FILE=/tmp/upload/merlinclash_log.txt

#name:设置为补丁包名字。每次补丁都需要重命名与补丁包一致
name=$1

	echo_date 开始复制文件！ >> $LOG_FILE
	echo_date 复制补丁文件！此步时间可能较长！
	#dbus set merlinclash_flag="384"
	#卸载模块
	rmmod ip_set_hash_mac.ko >/dev/null 2>&1 &
	dbus set merlinclash_bypassmode="1"
	dbus set merlinclash_tproxymode="closed"
	dir=/tmp/clashpatch/$name/clash
	a=$(ls $dir | wc -l)
	if [ $a -gt 0 ]; then
		#echo ""
		cp -rf /tmp/clashpatch/$name/clash/clashconfig.sh /koolshare/merlinclash/
		#0813-001才有
		#cp -rf /tmp/clashpatch/$name/clash/clash /koolshare/bin/
	fi
	
	#------网易云内容-----------
	dir=/tmp/clashpatch/$name/UnblockMusic
	a=$(ls $dir | wc -l)
	if [ $a -gt 0 ]; then
		cp -rf /tmp/clashpatch/$name/UnblockMusic/* /koolshare/bin/UnblockMusic/
	fi
	#------网易云内容-----------
	
	
	
	cp -rf /tmp/clashpatch/$name/version /koolshare/merlinclash/

	dir=/tmp/clashpatch/$name/yaml_basic
	a=$(ls $dir | wc -l)
	if [ $a -gt 0 ]; then

		cp -rf /tmp/clashpatch/$name/yaml_basic/* /koolshare/merlinclash/yaml_basic/
		#merlinclash_proxygroup_version="2020081701"
		#dbus set merlinclash_proxygroup_version=$merlinclash_proxygroup_version
	fi

	dir=/tmp/clashpatch/$name/yaml_dns
	a=$(ls $dir | wc -l)
	if [ $a -gt 0 ]; then
		cp -rf /tmp/clashpatch/$name/yaml_dns/* /koolshare/merlinclash/yaml_dns/
	fi

	dir=/tmp/clashpatch/$name/dashboard
	a=$(ls $dir | wc -l)
	if [ $a -gt 0 ]; then
		cp -rf /tmp/clashpatch/$name/dashboard/* /koolshare/merlinclash/dashboard/
	fi
	

	dir=/tmp/clashpatch/$name/scripts
	a=$(ls $dir | wc -l)
	if [ $a -gt 0 ]; then
		cp -rf /tmp/clashpatch/$name/scripts/* /koolshare/scripts/
		chmod 755 /koolshare/scripts/clash*
	fi
	
	dir=/tmp/clashpatch/$name/webs
	a=$(ls $dir | wc -l)
	if [ $a -gt 0 ]; then
		cp -rf /tmp/clashpatch/$name/webs/* /koolshare/webs/
	fi
	
	dir=/tmp/clashpatch/$name/res
	a=$(ls $dir | wc -l)
	if [ $a -gt 0 ]; then
		cp -rf /tmp/clashpatch/$name/res/* /koolshare/res/
	fi
	
	
	if [ "$ROG" == "1" ];then
		cp -rf /tmp/clashpatch/$name/rog/res/merlinclash.css /koolshare/res/
    fi