#!/bin/sh

export KSROOT=/koolshare
source $KSROOT/scripts/base.sh
eval $(dbus export merlinclash_)
alias echo_date='echo 【$(date +%Y年%m月%d日\ %X)】:'
LOG_FILE=/tmp/upload/merlinclash_log.txt

rm -rf /tmp/upload/merlinclash_log.txt
rm -rf /tmp/upload/*.yaml
LOCK_FILE=/var/lock/yaml_online_update.lock
flag=0
upname=""
upname_tmp=""
subscription_type="1"
dictionary=/koolshare/merlinclash/yaml_bak/subscription.txt
updateflag=""
Regularlog=/tmp/upload/merlinclash_regular.log

start_online_update(){
	updateflag="start_online_update"
	merlinc_link=$merlinclash_links
	LINK_FORMAT=$(echo "$merlinc_link" | grep -E "^http://|^https://")
	echo_date "订阅地址是：$LINK_FORMAT"
	if [ -z "$LINK_FORMAT" ]; then
		echo_date "订阅地址错误！检测到你输入的订阅地址并不是标准网址格式！"
		sleep 2
		echo_date "退出订阅程序" >> $LOG_FILE
	else
		upname_tmp=$merlinclash_uploadrename
		
		time=$(date "+%Y%m%d-%H%M%S")
		newname=$(echo $time | awk -F'-' '{print $2}')
		if [ -n "$upname_tmp" ]; then
			upname=$upname_tmp.yaml
		else
			upname=$newname.yaml
		fi
		echo_date "上传文件重命名为：$upname" >> $LOG_FILE
		#echo_date merlinclash_link=$merlinc_link >> $LOG_FILE
		#wget下载文件
		#wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$merlinc_link"
		echo_date "使用常规网络下载..." >> $LOG_FILE
		curl -4sSk --connect-timeout 20 $merlinc_link > /tmp/upload/$upname
		echo_date "配置文件下载完成" >>$LOG_FILE
		#虽然为0但是还是要检测下是否下载到正确的内容
		if [ "$?" == "0" ];then
			#下载为空...
			if [ -z "$(cat /tmp/upload/$upname)" ]; then
				#echo_date "下载内容为空..."
				echo_date "使用curl下载成功，但是内容为空，尝试更换wget进行下载..."	>> $LOG_FILE
				rm /tmp/upload/$upname
				if [ -n $(echo $merlinc_link | grep -E "^https") ]; then
					wget --no-check-certificate --timeout=15 -qO /tmp/upload/$upname $merlinc_link			
				else
					wget --timeout=15 -qO /tmp/upload/$upname $merlinc_link	
				fi
			else	
				#订阅地址有跳转
				local blank=$(cat /tmp/upload/$upname | grep -E " |Redirecting|301")
				if [ -n "$blank" ]; then
					echo_date "订阅链接可能有跳转，尝试更换wget进行下载..." >> $LOG_FILE
					rm /tmp/upload/$upname
					if [ -n $(echo $merlinc_link | grep -E "^https") ]; then
						wget --no-check-certificate --timeout=15 -qO /tmp/upload/$upname $merlinc_link
					else
						wget --timeout=15 -qO /tmp/upload/$upname $merlinc_link	
					fi
				fi
			fi
			if [ -z "$(cat /tmp/upload/$upname)" ]; then
				echo_date "wget下载内容为空..." >> $LOG_FILE
				failed_warning_clash
			fi
		else
			echo_date "使用curl下载订阅失败，尝试更换wget进行下载..." >> $LOG_FILE
			rm /tmp/upload/$upname
			if [ -n $(echo $merlinc_link | grep -E "^https") ]; then
				wget --no-check-certificate --timeout=15 -qO /tmp/upload/$upname $merlinc_link
			else
				wget --timeout=15 -qO /tmp/upload/$upname $merlinc_link	
			fi

			if [ "$?" == "0" ]; then
				#下载为空...
				if [ -z "$(cat /tmp/upload/$upname)" ]; then
					echo_date "wget下载内容为空..." >> $LOG_FILE
					failed_warning_clash
				fi
			else
				echo_date "wget下载订阅失败..." >> $LOG_FILE
				failed_warning_clash
			fi
		fi
		echo_date "已获取clash配置文件" >> $LOG_FILE
		echo_date "yaml文件合法性检查" >> $LOG_FILE
		check_yamlfile
		if [ $flag == "1" ]; then
		#后台执行上传文件名.yaml处理工作，包括去注释，去空白行，去除dns以上头部，将标准头部文件复制一份到/tmp/ 跟tmp的标准头部文件合并，生成新的head.yaml，再将head.yaml复制到/koolshare/merlinclash/并命名为upload.yaml
			echo_date "后台执行yaml文件处理工作" >> $LOG_FILE
			sh /koolshare/scripts/clash_yaml_sub.sh >/dev/null 2>&1 &
			#20200803写入字典
			write_dictionary					
		else
			echo_date "yaml文件格式不合法" >> $LOG_FILE
		fi		
	fi
}

start_regular_update(){
	updateflag="start_regular_update"
	merlinc_link=$2
	upname=$1
	echo_date "【配置名是：$upname" >> $Regularlog
	upname=$upname.yaml
	#wget --no-check-certificate -t3 -T30 -4 -O /tmp/upload/$upname "$merlinc_link"
	echo_date "使用常规网络下载..." >> $Regularlog
	curl -4sSk --connect-timeout 20 $merlinc_link > /tmp/upload/$upname
	echo_date "订阅下载完成" >> $Regularlog
	#虽然为0但是还是要检测下是否下载到正确的内容
	if [ "$?" == "0" ];then
		#下载为空...
		if [ -z "$(cat /tmp/upload/$upname)" ]; then
			#echo_date "下载内容为空..."
			echo_date "使用curl下载成功，但是内容为空，尝试更换wget进行下载..."	>> $Regularlog
			rm /tmp/upload/$upname
			if [ -n $(echo $merlinc_link | grep -E "^https") ]; then
				wget --no-check-certificate --timeout=15 -qO /tmp/upload/$upname $merlinc_link			
			else
				wget --timeout=15 -qO /tmp/upload/$upname $merlinc_link	
			fi
		else	
			#订阅地址有跳转
			local blank=$(cat /tmp/upload/$upname | grep -E " |Redirecting|301")
			if [ -n "$blank" ]; then
				echo_date "订阅链接可能有跳转，尝试更换wget进行下载..." >> $Regularlog
				rm /tmp/upload/$upname
				if [ -n $(echo $merlinc_link | grep -E "^https") ]; then
					wget --no-check-certificate --timeout=15 -qO /tmp/upload/$upname $merlinc_link
				else
					wget --timeout=15 -qO /tmp/upload/$upname $merlinc_link	
				fi
			fi
		fi
		if [ -z "$(cat /tmp/upload/$upname)" ]; then
			echo_date "wget下载内容为空..." >> $Regularlog
			failed_warning_clash
		fi
	else
		echo_date "使用curl下载订阅失败，尝试更换wget进行下载..." >> $Regularlog
		rm /tmp/upload/$upname
		if [ -n $(echo $merlinc_link | grep -E "^https") ]; then
			wget --no-check-certificate --timeout=15 -qO /tmp/upload/$upname $merlinc_link
		else
			wget --timeout=15 -qO /tmp/upload/$upname $merlinc_link	
		fi
		if [ "$?" == "0" ]; then
			#下载为空...
			if [ -z "$(cat /tmp/upload/$upname)" ]; then
				echo_date "wget下载内容为空..." >> $Regularlog
				failed_warning_clash
			fi
		else
			echo_date "wget下载订阅失败..." >> $Regularlog
			failed_warning_clash
		fi
	fi
	echo_date "已获取clash配置文件" >> $Regularlog
	echo_date "yaml文件合法性检查" >> $Regularlog
	check_yamlfile
	if [ $flag == "1" ]; then
	#后台执行上传文件名.yaml处理工作，包括去注释，去空白行，去除dns以上头部，将标准头部文件复制一份到/tmp/ 跟tmp的标准头部文件合并，生成新的head.yaml，再将head.yaml复制到/koolshare/merlinclash/并命名为upload.yaml
		echo_date "后台执行yaml文件处理工作" >> $Regularlog
		sh /koolshare/scripts/clash_yaml_sub.sh >/dev/null 2>&1 &
		#20200803写入字典
		write_dictionary					
	else
		echo_date "yaml文件格式不合法" >> $Regularlog
	fi
}

write_dictionary(){
	if [ -f "$dictionary" ]; then
		name_tmp=$(cat $dictionary | grep -w -n "$upname" | awk -F ":" '{print $1}')
		#定位配置名行数，存在，则覆写；不存在，则新增 -w全字符匹配
		if [ -n "$name_tmp" ]; then
			if [ "$updateflag" == "start_online_update" ]; then			
				echo_date "【在线clash订阅】配置名存在，覆写" >> $LOG_FILE
				sed -i "$name_tmp d" $dictionary
				echo \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\" >> $dictionary
				#sed -i "$name_tmp i \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\" " $dictionary
				#sed -i "s?^\"name\":\"$upname\",*$""?^\"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\"?g" $dictionary
			fi
		else
			#新增
			echo_date "配置名不存在，新增" >> $LOG_FILE
			echo \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\" >> $dictionary
		fi
	else
		#为初次订阅，直接写入
		echo_date "初次订阅，直接写入" >> $LOG_FILE
		echo \"name\":\"$upname\",\"link\":\"$merlinc_link\",\"type\":\"$subscription_type\",\"use\":\"0\" >> $dictionary
	fi
	
}
failed_warning_clash(){
	rm -rf /tmp/upload/$upname
	echo_date "获取文件失败！！请检查网络！" >> $LOG_FILE
	echo_date "===================================================================" >> $LOG_FILE
	echo BBABBBBC
	exit 1
}

check_yamlfile(){
	#通过获取的文件是否存在port: Rule: Proxy: Proxy Group: 标题头确认合法性
	#先处理下文本
	sh /koolshare/scripts/clash_string.sh /tmp/upload/$upname
	echo_date "文件格式标准化处理" >>"$LOG_FILE"
    #将所有DNS都转化成dns
    sed -i 's/DNS/dns/g' /tmp/upload/$upname
    #部分存在...导致文档结束而出错,先清除
    para0=$(sed -n '/^\.\.\./p' /tmp/upload/$upname)
    if [ -n "$para0" ] ; then
        sed -i 's/\.\.\.//g' /tmp/upload/$upname
    fi
    #老格式处理
    #当文件存在Proxy:开头的行数，将Proxy: ~替换成空格
    para0=$(sed -n '/^\.\.\./p' /tmp/upload/$upname)
    if [ -n "$para0" ] ; then
        sed -i 's/^\.\.\.//g' /tmp/upload/$upname
    fi
    
    para1=$(sed -n '/^Proxy: ~/p' /tmp/upload/$upname)
    if [ -n "$para1" ] ; then
        sed -i 's/Proxy: ~//g' /tmp/upload/$upname
    fi

    para2=$(sed -n '/^Proxy Group: ~/p' /tmp/upload/$upname)
    #当文件存在Proxy Group:开头的行数，将Proxy Group: ~替换成空格
    if [ -n "$para2" ] ; then
        sed -i 's/Proxy Group: ~//g' /tmp/upload/$upname
    fi
    #当文件存在奇葩声明，删除，重写
    pg_line=$(grep -n "Proxy Group" /tmp/upload/$upname | awk -F ":" '{print $1}' )
    if [ -n "$pg_line" ] ; then
        sed -i "$pg_line d" /tmp/upload/$upname
        sed -i "$pg_line i proxy-groups:" /tmp/upload/$upname
    fi
    para3=$(sed -n '/Rule: ~/p' /tmp/upload/$upname)
    #当文件存在Rule:开头的行数，将Rule: ~替换成空格
    if [ -n "$para3" ] ; then
        echo_date "将Rule: ~替换成空格" >> $LOG_FILE
        sed -i 's/Rule: ~//g' /tmp/upload/$upname
    fi
    #当文件存在Proxy:开头的行数，将Proxy:替换成proxies:
    para1=$(sed -n '/^Proxy:/p' /tmp/upload/$upname)
    if [ -n "$para1" ] ; then
        sed -i 's/Proxy:/proxies:/g' /tmp/upload/$upname
    fi

    para2=$(sed -n '/^Proxy Group:/p' /tmp/upload/$upname)
    #当文件存在Proxy Group:开头的行数，将Proxy Group:替换成proxy-groups:
    if [ -n "$para2" ] ; then
        sed -i 's/Proxy Group:/proxy-groups:/g' /tmp/upload/$upname
    fi

    para3=$(sed -n '/Rule:/p' /tmp/upload/$upname)
    #当文件存在Rule:开头的行数，将Rule:替换成rules:
    if [ -n "$para3" ] ; then
        sed -i 's/Rule:/rules:/g' /tmp/upload/$upname
    fi
	para1=$(sed -n '/^port:/p' /tmp/upload/$upname)
	para1_1=$(sed -n '/^mixed-port:/p' /tmp/upload/$upname)
	#para2=$(sed -n '/^socks-port:/p' /tmp/upload/$upname)
	#para3=$(sed -n '/^mode:/p' /tmp/upload/$upname)
	#para4=$(sed -n '/^name:/p' /tmp/upload/upload.yaml)
	#para5=$(sed -n '/^type:/p' /tmp/upload/upload.yaml)
	proxies_line=$(cat /tmp/upload/$upname | grep -n "^proxies:" | awk -F ":" '{print $1}')
	#20200902+++++++++++++++
	#COMP 左>右，值-1；左等于右，值0；左<右，值1
	port_line=$(cat /tmp/upload/$upname | grep -n "^port:" | awk -F ":" '{print $1}')
	echo_date "port:行数为$port_line" >> $LOG_FILE
	echo_date "proxies:行数为$proxies_line" >> $LOG_FILE
	if [ -z "$port_line" ] ; then
		echo_date "配置文件缺少port:开头行，无法创建yaml文件" >> $LOG_FILE
		#rm -rf /tmp/upload/$upname
		echo BBABBBBC >> $LOG_FILE
		exit 1

	fi
	if [ -z "$proxies_line" ]; then
		echo_date "配置文件缺少proxies:开头行，无法创建yaml文件" >> $LOG_FILE
		#rm -rf /tmp/upload/$upname
		echo BBABBBBC >> $LOG_FILE
		exit 1

	fi
	if [ -z "$para1" ] && [ -z "$para1_1" ]; then
		echo_date "clash配置文件不是合法的yaml文件，请检查订阅连接是否有误" >> $LOG_FILE
		rm -rf /tmp/upload/$upname
	else
		echo_date "clash配置文件检查通过" >> $LOG_FILE
		flag=1
	fi
}
set_lock(){
	exec 233>"$LOCK_FILE"
	flock -n 233 || {
		echo_date "订阅脚本已经在运行，请稍候再试！" >> $LOG_FILE	
		unset_lock
	}
}

unset_lock(){
	flock -u 233
	rm -rf "$LOCK_FILE"
}

case $2 in
2)
	#set_lock
	echo "" > $LOG_FILE
	http_response "$1"
	echo_date "在线clash订阅" >> $LOG_FILE
	echo_date "clash订阅链接处理" >> $LOG_FILE
	start_online_update >> $LOG_FILE
	echo BBABBBBC >> $LOG_FILE
	#unset_lock
	;;
1)
	echo_date "clash订阅定时更新" >> $LOG_FILE
	echo_date "clash订阅定时更新" >> $Regularlog
	start_regular_update "$1" "$3" >> $LOG_FILE
	echo_date "" >> $Regularlog
	echo BBABBBBC >> $LOG_FILE
	;;
esac

